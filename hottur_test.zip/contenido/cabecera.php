
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Hottur</title>


    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    
    <link href="../css/sweetalert.css" rel="stylesheet">  
    
    <link href="../css/datatables.min.css" rel="stylesheet">
    <link href="../css/buttons.dataTables.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="../css/sb-admin.css" rel="stylesheet">
   
   <!-- data toggle inicio -->
   <link href="../css/bootstrap-toggle.min.css" rel="stylesheet">
   <!-- data toggle FIN -->

    <!-- Custom Fonts -->
    <link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href="../css/estilosmenu.css" rel="stylesheet">  
    <link href="../css/dataTables.bootstrap.min.css" rel="stylesheet">  
    <link href="../css/jquery.dataTables.min.css" rel="stylesheet">  

    
     <!-- Date Time Picker Boostrap-->
   <link rel="stylesheet" href="../css/bootstrap-datetimepicker.css">
   <link rel="stylesheet" href="../css/bootstrap-datetimepicker.min.css">
   <link rel="stylesheet" href="../css/bootstrap-datetimepicker-standalone.css">

   <link rel="stylesheet" href="../css/fullcalendar.css">

   <!-- AutoCompletar -->
   <link rel="stylesheet" href="../css/jquery-ui.css">