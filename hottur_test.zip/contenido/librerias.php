<!-- jQuery -->


<script src="../js/jquery.js"></script>

<!--script src="../js/jquery.min.js"></script-->

<!-- esto es para las alertas -->
<script src="../js/bootstrap.min.js"></script>
<script src="../js/sweetalert.js"></script>
<script src="../js/sweetalert.min.js"></script>

<!-- Bootstrap Core JavaScript -->

<script src="../js/jquery.dataTables.js"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="../js/dataTables.bootstrap.min.js"></script>
<script src="../js/dataTables.buttons.min.js"></script>
<script src="../js/buttons.flash.min.js"></script>
<script src="../js/jszip.min.js"></script>
<script src="../js/pdfmake.min.js"></script>
<script src="../js/vfs_fonts.js"></script>
<script src="../js/buttons.html5.min.js"></script>
<script src="../js/buttons.print.min.js"></script>

<!-- toggle -->
<script src="../js/bootstrap-toggle.min.js"></script>




<!-- Date Time Picker-->
<script src="../js/moment.js"></script>
<script src="../js/bootstrap-datetimepicker.min.js"></script>
<script src="../js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript" src="../js/transition.js"></script>
<script type="text/javascript" src="../js/collapse.js"></script>

<script type="text/javascript" src="../js/fullcalendar.js"></script>



<script src="../js/funciones.js"></script>
<script src="../js/ListarTablas.js"></script>

<!-- AutoCompletar -->
<script src="../js/jquery-ui.js"></script>
<script src="../js/jquery.abacus.min.js"></script>
<!-- imprimir datos -->
<script src="../js/Imprimir.js"></script>
<!-- Generar PDFs -->


<script src="../js/GenerarPDFs.js"></script>
