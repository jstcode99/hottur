<nav class="navbar navbar-inverse navbar-fixed-bottom">
  <div class="container">
	<h4  class="navbar-text navbar-center" >Hottur</h4>
	<p class="navbar-text">Desarrollado por </p>
  </div>
</nav>