<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <div class="panel panel-default">
                <div class="panel-body">
                    <form class="form-horizontal">

                        <legend>Registro de Tipo Contribuyente</legend>

                            <div class="form-group">
                            
                                <label for="TipoContribuyenteNombre" class="col-sm-5 control-label">Tipo contribuyente</label>
                                <div class="col-sm-7">
                                    <input type="text"  name="TipoContribuyenteNombre" id="TipoContribuyenteNombre" class="form-control" placeholder="Tipo Contribuyente">
                                </div>
                            </div>
                           
                            <div class="form-group">
                            <div class="col-sm-5"></div>
                            <div class="col-sm-7">
                            <button type="button" onclick="TipoContribuyenteRegistrar();" class="btn btn-success btn-md">Guardar</button>

                            </div>
                            <br>
                        </div>
                    </form>

                    <br>
                </div>
            </div>
        </div>
    </div>
</div>
