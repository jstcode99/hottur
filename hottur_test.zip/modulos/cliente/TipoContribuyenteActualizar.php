
<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <div class="panel panel-default">
                <div class="panel-body">
                    <form class="form-horizontal">

                        <legend>Actualizar de Tipo Contribuyente</legend>

                            <div class="form-group">
                            
                                <label for="ActualizarTipoContribuyenteCodigo" class="col-sm-5 control-label">Tipo contribuyente Codigo</label>
                                <div class="col-sm-7">
                                    <input type="text" disabled  name="ActualizarTipoContribuyenteCodigo" id="ActualizarTipoContribuyenteCodigo" class="form-control" placeholder="Codigo Tipo Contribuyente">
                                </div>
                            </div>

                            <div class="form-group">
                            
                                <label for="ActualizarTipoContribuyenteNombre" class="col-sm-5 control-label">Tipo contribuyente Nombre</label>
                                <div class="col-sm-7">
                                    <input type="text"  name="ActualizarTipoContribuyenteNombre" id="ActualizarTipoContribuyenteNombre" class="form-control" placeholder="Nombre Tipo Contribuyente">
                                </div>
                            </div>
                           
                            <div class="form-group">
                            <div class="col-sm-5"></div>
                            <div class="col-sm-7">
                            <button type="button" onclick="ActualizarTipoContribuyente();" class="btn btn-warning btn-md">Actualizar</button>

                            </div>
                            <br>
                        </div>
                    </form>

                    <br>
                </div>
            </div>
        </div>
    </div>
</div>
