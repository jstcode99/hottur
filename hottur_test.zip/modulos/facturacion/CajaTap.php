<script type="text/javascript" src="../js/ListarTablas.js"></script>
<br><br>
<div class="page-wrapper">
    <div class="panel panel-default"> 
        <?php
            include('AbrirCaja.php');
        ?>  
    </div>
</div>