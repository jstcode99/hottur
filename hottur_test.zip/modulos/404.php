<div class="jumbotron">
  <h1>Error, 404!</h1>
  <p>La página que buscas no se encuentra</p>
  <p><a class="btn btn-primary btn-lg" href="" role="button">Volver</a></p>
</div>