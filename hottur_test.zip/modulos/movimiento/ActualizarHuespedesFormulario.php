<script src="../js/AutoCompletar.JS"></script>
        <div class="panel-default">  
                <div class="panel-body">                                 
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                        <br><legend>&nbsp;&nbsp;Huesped</legend>
                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                        <div class="form-group">
                                                                <label for="TipoHuespedActualizarHuesped" class="label-control">Tipo Huesped</label>
                                                                 <select class="form-control" required placeholder="Tipo Huesped" id="TipoHuespedActualizarHuesped">
                                                                 <option value="ADULTO">ADULTO</option>
                                                                 <option value="NINO">NIÑO</option>
                                                                 </select>
                                                        </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                        <div class="form-group">
                                                                <label class="label-control" for="TipoDocumentoHuespedActualizar">Tipo Documento</label>
                                                                <select  class="form-control" id="TipoDocumentoHuespedActualizar">
                                                                        <option value="CEDULA DE CIUDADANIA">CEDULA DE CIUDADANIA</option>
                                                                        <option value="TARJETA DE IDENTIDAD">TARJETA DE IDENTIDAD</option>
                                                                        <option value="CEDULA DE EXTRANJERIA">CEDULA DE EXTRANJERIA</option>
                                                                        <option value="PASAPORTE">PASAPORTE</option>
                                                                        <option value='TARJETA EXTRANJERIA'>TARJETA EXTRANJERIA</option>
                                                                        <option value='REGISTRO CIVIL'>REGISTRO CIVIL</option>
                                                                </select>
                                                        </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                        <div class="form-group">
                                                                 <label class="label-control">Numero Documento</label>                                                        
                                                                <input class="form-control"  placeholder="Numero Documento" id="NumeroDocumentoHuespedActualizar" />
                                                        </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                        <div class="form-group">
                                                                <label class="label-control">Nacionalidad</label>  
                                                                <input class="form-control"   placeholder="Nacionalidad" id="NacionalidadHuespedHuespedActualizar" />                                                                
                                                        </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-3 col-md-3">
                                                        <div class="form-group">
                                                                <label for="FechaEntrada">Fecha Nacimiento</label>
                                                                <div class='input-group date' id='FechaNacimiento'>
                                                                        <input type='text' id="FechaNacimientoHuespedActualizar" class="form-control" />
                                                                        <span class="input-group-addon">
                                                                            <span class="glyphicon glyphicon-calendar"></span>
                                                                        </span>
                                                                </div>             
                                                        </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-4 col-md-4">
                                                        <div class="form-group">
                                                                <label class="label-control">Nombre</label>                       
                                                                <input class="form-control"    placeholder="Nombre" id="NombreHuespedHuespedActualizar" />                                                                                           
                                                        </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-5 col-md-5">
                                                        <div class="form-group">
                                                                <label class="label-control">Apellidos</label>                           
                                                                <input  class="form-control"   placeholder="Apellido" id="ApellidoHuespedHuespedActualizar" />                                                    
                                                        </div>
                                        </div>   
                                </div>
                                <div class="con-xs-12 col-sm-12 col-md-12">
                                        <div class="col-xs-12 col-sm-4 col-md-4"></div>
                                        <button type="button" id="BtnAgregarHuespedesHuespedActualizar"  onclick="ActualizarHuespedDatosCargados();" class="col-xs-12 col-sm-4 col-md-4 btn btn-warning" style="margin-top:5px">Actualizar</button>
                                        <div class="col-xs-12 col-sm-4 col-md-4"></div>
                                </div>
                </div>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
        </div>  
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
<script src="../js/ActivarDateTimes.js"></script>
                        