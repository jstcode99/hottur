<script src="../js/AutoCompletar.JS"></script>
<script src="../js/ActivarDateTimes.js"></script>
        <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="panel-body">
                                <form action="" class="form-inline">
                                        <label for="FechaMovimientoEspecifico">Fecha Movimiento Especifico</label>
                                        <div class="col-xs-12 col-sm-12 col-md-12">
                                                            <div class="input-group date" id="FechaEntrada"  >
                                                                            <input type="text" id="EspecificoMovimintoFechaEntrada"   class="form-control">
                                                                            <span class="input-group-addon">
                                                                                <span class="glyphicon glyphicon-calendar"></span>
                                                                            </span>
                                    <button type="button" class="form-control btn btn-primary" onclick="ConsultaMovimientoEspecifico()">Consultar</button>
                                                            </div>
                                    </div>
                                </form>
                        </div>
                </div>
        </div>
        <div class="panel-default">

                <div id="CargarTablaMovimientoEspecifico">
                </div>

        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
                
        </div>  
        

        




                        