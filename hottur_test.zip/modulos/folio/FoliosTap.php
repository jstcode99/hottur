<script type="text/javascript" src="../js/ListarTablas.js"></script>
<br><br>
<div class="page-wrapper">
    <div class="container-fluid" style="height:auto">
                <?php
                    include('ConsultarFolio.php');
                ?>                
        </div>
    </div>
</div>