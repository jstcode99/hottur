<script type="text/javascript" src="../js/ListarTablas.js"></script>
<br><br>
<div class="page-wrapper">
    <div class="container-fluid" style="height:auto">
        <div class="panel panel-default">
            <div class="panel-panel-body">
                <?php
                    include('ConsumosGenerales.php');
                ?>    
            </div>        
        </div>
    </div>
</div>