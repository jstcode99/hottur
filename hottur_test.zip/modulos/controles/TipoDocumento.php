<option value='CEDULA DE CIUDADANIA'>CEDULA DE CIUDADANIA</option>
<option value='TARJETA DE IDENTIDAD'>TARJETA DE IDENTIDAD</option>
<option value='CEDULA DE EXTRANJERIA'>CEDULA DE EXTRANJERIA</option>
<option value='PASAPORTE'>PASAPORTE</option>
<option value='TARJETA EXTRANJERIA'>TARJETA EXTRANJERIA</option>
<option value='REGISTRO CIVIL'>REGISTRO CIVIL</option>
        



