<div class="container">
    <div class="row">
        <div class="col-sm-6">
            <div class="panel panel-default">
                <div class="panel-body">
                    <form class="form-horizontal">

                        <legend>Registro Tipo de Habitaciones</legend>
                            <div class="form-group">
                                <label for="TipoHabitacionNombreRegistrar" class="col-sm-3 control-label">Nombre Tipo Habitación</label>
                                <div class="col-sm-9">
                                    <input type="text" name="TipoHabitacionNombreRegistrar" id="TipoHabitacionNombreRegistrar" class="form-control" placeholder="Nombre Tipo Habitación">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="TipoHabitacionCantidadPaxRegistrar" class="col-sm-3 control-label">Cantidad Pax </label>
                                <div class="col-sm-9">
                                    <input type="text" name="TipoHabitacionCantidadPaxRegistrar" id="TipoHabitacionCantidadPaxRegistrar" class="form-control" placeholder="Cantidad Pax">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="TipoHabitacionValorPaxRegistrar" class="col-sm-3 control-label">Valor Pax</label>
                                <div class="col-sm-9">
                                    <input type="text" name="TipoHabitacionValorPaxRegistrar" id="TipoHabitacionValorPaxRegistrar" class="form-control" placeholder="Valor Pax">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="TipoHabitacionValorAdicionalRegistrar" class="col-sm-3 control-label">Valor Adicional</label>
                                <div class="col-sm-9">
                                    <input type="text" name="TipoHabitacionValorAdicionalRegistrar" id="TipoHabitacionValorAdicionalRegistrar" class="form-control" placeholder="Valor Adicional">
                                </div>
                            </div>
                            <div class="form-group">
                            <div class="col-sm-9">
                            </div>
                            <button type="button" onclick="TipoHabitacionRegistrar();" class="btn btn-primary btn-md">Guardar</button>
                            
                        </div>
                    </form>

                    <br>
                    <br>
                    <br>
                </div>
            </div>
        </div>
    </div>
</div>